export {
  categories,
  getCategoryName,
  seedMenuItems,
  type Category,
  type MenuItem,
  type MenuItemInput,
} from '@/lib/menu';

