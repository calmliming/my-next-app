import OrderPageClient from '@/components/order/OrderPageClient';

export default function OrderPage() {
  return <OrderPageClient />;
}

