import OrderHistoryClient from '@/components/order/OrderHistoryClient';

export default function OrderHistoryPage() {
  return <OrderHistoryClient />;
}
