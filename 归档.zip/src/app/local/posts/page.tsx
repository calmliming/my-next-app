import Posts from "@/components/posts/posts";
export default function PostsPage() {
  return (
    <div className='pb-24'>
      <Posts />
    </div>
  );
}
