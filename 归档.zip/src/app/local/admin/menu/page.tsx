import AdminMenuPageClient from '@/components/admin/AdminMenuPageClient';

export default function AdminMenuPage() {
  return <AdminMenuPageClient />;
}

