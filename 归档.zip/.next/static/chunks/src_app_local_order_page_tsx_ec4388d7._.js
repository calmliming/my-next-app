(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f7813_next_bd9a3e60._.js",
  "static/chunks/src_b61cc6d4._.js"
],
    source: "dynamic"
});
