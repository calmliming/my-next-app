(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f7813_next_dist_compiled_next-devtools_index_670b3ccc.js",
  "static/chunks/f7813_next_dist_compiled_ee41808a._.js",
  "static/chunks/f7813_next_dist_shared_lib_89518780._.js",
  "static/chunks/f7813_next_dist_client_c1178090._.js",
  "static/chunks/f7813_next_dist_3f6d81d9._.js",
  "static/chunks/f7813_next_error_9d5059a2.js",
  "static/chunks/[next]_entry_page-loader_ts_526b83d6._.js",
  "static/chunks/c046a_react-dom_812c9f31._.js",
  "static/chunks/node_modules__pnpm_f012a4b7._.js",
  "static/chunks/[root-of-the-server]__092393de._.js"
],
    source: "entry"
});
