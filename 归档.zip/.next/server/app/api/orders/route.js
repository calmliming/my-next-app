var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/route.js")
R.c("server/chunks/f7813_next_e9eab169._.js")
R.c("server/chunks/[root-of-the-server]__8eb1c3df._.js")
R.m("[project]/.next-internal/server/app/api/orders/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/.pnpm/next@15.5.4_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/orders/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/.pnpm/next@15.5.4_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/orders/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
