module.exports = [
"[project]/.next-internal/server/app/api/menu/[id]/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/mongodb [external] (mongodb, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("mongodb", () => require("mongodb"));

module.exports = mod;
}),
"[project]/src/lib/db.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// lib/db.ts
__turbopack_context__.s([
    "getDb",
    ()=>getDb
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongodb [external] (mongodb, cjs)");
;
// 从环境变量获取连接地址（后面教你填）
const MONGODB_URI = process.env.MONGODB_URI || '';
// 数据库名称（随便起，比如"myBlog"）
const DB_NAME = 'myBlog';
// 缓存连接，避免重复创建连接
let client;
let clientPromise;
if (!MONGODB_URI) {
    throw new Error('请先在 .env.local 文件里填好 MONGODB_URI！');
}
if ("TURBOPACK compile-time truthy", 1) {
    // 开发环境：缓存连接（全局变量）
    if (!/*TURBOPACK member replacement*/ __turbopack_context__.g._mongoClientPromise) {
        client = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["MongoClient"](MONGODB_URI);
        /*TURBOPACK member replacement*/ __turbopack_context__.g._mongoClientPromise = client.connect();
    }
    clientPromise = /*TURBOPACK member replacement*/ __turbopack_context__.g._mongoClientPromise;
} else //TURBOPACK unreachable
;
async function getDb() {
    const client = await clientPromise;
    return client.db(DB_NAME);
}
}),
"[project]/src/lib/menu.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "categories",
    ()=>categories,
    "getCategoryName",
    ()=>getCategoryName,
    "seedMenuItems",
    ()=>seedMenuItems
]);
const categories = [
    {
        id: 'stirfry',
        name: '湘味小炒'
    },
    {
        id: 'noodle',
        name: '嗦粉吃面'
    },
    {
        id: 'hotpot',
        name: '热辣火锅'
    },
    {
        id: 'bbq',
        name: '夜宵烧烤'
    },
    {
        id: 'snack',
        name: '特色小吃'
    },
    {
        id: 'drink',
        name: '解辣神器'
    }
];
const seedMenuItems = [
    // --- 湘味小炒 ---
    {
        name: '辣椒炒肉',
        price: 38,
        categoryId: 'stirfry',
        img: 'https://images.unsplash.com/photo-1624386971932-d193f443a6d4?w=200&h=200&fit=crop',
        desc: '湘菜灵魂，螺丝椒炒土猪肉'
    },
    {
        name: '剁椒鱼头',
        price: 68,
        categoryId: 'stirfry',
        img: 'https://images.unsplash.com/photo-1624386971932-d193f443a6d4?w=200&h=200&fit=crop',
        desc: '鲜辣爽口，鱼肉嫩滑'
    },
    {
        name: '小炒黄牛肉',
        price: 48,
        categoryId: 'stirfry',
        img: 'https://images.unsplash.com/photo-1541544741938-0af808871cc0?w=200&h=200&fit=crop',
        desc: '野山椒爆炒，下饭神器'
    },
    {
        name: '大碗花菜',
        price: 26,
        categoryId: 'stirfry',
        img: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200&h=200&fit=crop',
        desc: '有机花菜，五花肉煸香'
    },
    // --- 嗦粉吃面 ---
    {
        name: '长沙肉丝粉',
        price: 16,
        categoryId: 'noodle',
        img: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=200&h=200&fit=crop',
        desc: '骨汤打底，手工宽粉'
    },
    {
        name: '酸豆角肉末粉',
        price: 18,
        categoryId: 'noodle',
        img: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=200&h=200&fit=crop',
        desc: '酸爽开胃，满满肉末'
    },
    // --- 热辣火锅 ---
    {
        name: '麻辣牛肉火锅',
        price: 128,
        categoryId: 'hotpot',
        img: 'https://images.unsplash.com/photo-1541544741938-0af808871cc0?w=200&h=200&fit=crop',
        desc: '牛骨慢炖，鲜切吊龙'
    },
    {
        name: '干锅肥肠',
        price: 58,
        categoryId: 'hotpot',
        img: 'https://images.unsplash.com/photo-1541544741938-0af808871cc0?w=200&h=200&fit=crop',
        desc: '处理干净，香辣Q弹'
    },
    // --- 夜宵烧烤 ---
    {
        name: '烤羊肉串(5串)',
        price: 25,
        categoryId: 'bbq',
        img: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=200&h=200&fit=crop',
        desc: '孜然飘香，肥瘦相间'
    },
    {
        name: '烤牛油(10串)',
        price: 20,
        categoryId: 'bbq',
        img: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=200&h=200&fit=crop',
        desc: '奶香十足，一口爆油'
    },
    // --- 特色小吃 ---
    {
        name: '长沙臭豆腐',
        price: 15,
        categoryId: 'snack',
        img: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=200&h=200&fit=crop',
        desc: '闻着臭吃着香，外酥里嫩'
    },
    {
        name: '糖油粑粑',
        price: 12,
        categoryId: 'snack',
        img: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=200&h=200&fit=crop',
        desc: '糯叽叽，甜而不腻'
    },
    // --- 解辣神器 ---
    {
        name: '冰镇豆浆',
        price: 6,
        categoryId: 'drink',
        img: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=200&h=200&fit=crop',
        desc: '现磨豆浆，解辣首选'
    },
    {
        name: '大桶柠檬茶',
        price: 18,
        categoryId: 'drink',
        img: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=200&h=200&fit=crop',
        desc: '暴打柠檬，清爽解腻'
    }
];
function getCategoryName(categoryId) {
    return categories.find((c)=>c.id === categoryId)?.name ?? categoryId;
}
}),
"[project]/src/app/api/menu/[id]/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DELETE",
    ()=>DELETE,
    "GET",
    ()=>GET,
    "PUT",
    ()=>PUT
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.4_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/mongodb [external] (mongodb, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$menu$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/menu.ts [app-route] (ecmascript)");
;
;
;
;
function isNonEmptyString(v) {
    return typeof v === 'string' && v.trim().length > 0;
}
function isFiniteNumber(v) {
    return typeof v === 'number' && Number.isFinite(v);
}
async function GET(request, { params }) {
    try {
        const id = (await params).id;
        if (!__TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"].isValid(id)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                code: 400,
                data: null,
                msg: '无效的菜品ID'
            }, {
                status: 400
            });
        }
        const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
        const item = await db.collection('menuItems').findOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        });
        if (!item) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                code: 404,
                data: null,
                msg: '菜品不存在'
            }, {
                status: 404
            });
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            code: 200,
            data: {
                id: item._id.toString(),
                name: item.name,
                price: item.price,
                categoryId: item.categoryId,
                img: item.img,
                desc: item.desc,
                isActive: Boolean(item.isActive),
                createdAt: new Date(item.createdAt).toISOString(),
                updatedAt: new Date(item.updatedAt).toISOString()
            },
            msg: '读取成功'
        });
    } catch (error) {
        console.error('读取菜品失败：', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            code: 500,
            data: null,
            msg: '读取菜品失败'
        }, {
            status: 500
        });
    }
}
async function PUT(request, { params }) {
    try {
        const id = (await params).id;
        if (!__TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"].isValid(id)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                code: 400,
                data: null,
                msg: '无效的菜品ID'
            }, {
                status: 400
            });
        }
        const payload = await request.json();
        if (!payload || typeof payload !== 'object') {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                code: 400,
                data: null,
                msg: '参数不合法'
            }, {
                status: 400
            });
        }
        const p = payload;
        const update = {};
        if (typeof p.isActive === 'boolean') update.isActive = p.isActive;
        if (typeof p.name !== 'undefined') {
            if (!isNonEmptyString(p.name)) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    code: 400,
                    data: null,
                    msg: '菜名不能为空'
                }, {
                    status: 400
                });
            }
            update.name = p.name.trim();
        }
        if (typeof p.price !== 'undefined') {
            if (!isFiniteNumber(p.price) || p.price < 0) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    code: 400,
                    data: null,
                    msg: '价格不合法'
                }, {
                    status: 400
                });
            }
            update.price = p.price;
        }
        if (typeof p.categoryId !== 'undefined') {
            if (!isNonEmptyString(p.categoryId) || !__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$menu$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["categories"].some((c)=>c.id === p.categoryId)) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    code: 400,
                    data: null,
                    msg: '分类不合法'
                }, {
                    status: 400
                });
            }
            update.categoryId = p.categoryId;
        }
        if (typeof p.img !== 'undefined') {
            if (!isNonEmptyString(p.img)) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    code: 400,
                    data: null,
                    msg: '图片地址不能为空'
                }, {
                    status: 400
                });
            }
            update.img = p.img.trim();
        }
        if (typeof p.desc !== 'undefined') {
            if (!isNonEmptyString(p.desc)) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    code: 400,
                    data: null,
                    msg: '描述不能为空'
                }, {
                    status: 400
                });
            }
            update.desc = p.desc.trim();
        }
        update.updatedAt = new Date();
        const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
        const col = db.collection('menuItems');
        const result = await col.updateOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        }, {
            $set: update
        });
        if (result.matchedCount === 0) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                code: 404,
                data: null,
                msg: '菜品不存在'
            }, {
                status: 404
            });
        }
        const item = await col.findOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            code: 200,
            data: {
                id: item._id.toString(),
                name: item.name,
                price: item.price,
                categoryId: item.categoryId,
                img: item.img,
                desc: item.desc,
                isActive: Boolean(item.isActive),
                createdAt: new Date(item.createdAt).toISOString(),
                updatedAt: new Date(item.updatedAt).toISOString()
            },
            msg: '更新成功'
        });
    } catch (error) {
        console.error('更新菜品失败：', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            code: 500,
            data: null,
            msg: '更新菜品失败'
        }, {
            status: 500
        });
    }
}
async function DELETE(request, { params }) {
    try {
        const id = (await params).id;
        if (!__TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"].isValid(id)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                code: 400,
                data: null,
                msg: '无效的菜品ID'
            }, {
                status: 400
            });
        }
        const db = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDb"])();
        const result = await db.collection('menuItems').deleteOne({
            _id: new __TURBOPACK__imported__module__$5b$externals$5d2f$mongodb__$5b$external$5d$__$28$mongodb$2c$__cjs$29$__["ObjectId"](id)
        });
        if (result.deletedCount === 0) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                code: 404,
                data: null,
                msg: '菜品不存在'
            }, {
                status: 404
            });
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            code: 200,
            data: null,
            msg: '删除成功'
        });
    } catch (error) {
        console.error('删除菜品失败：', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$4_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            code: 500,
            data: null,
            msg: '删除菜品失败'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__2cdd7b44._.js.map