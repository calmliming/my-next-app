globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/f7813_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_be2445a1._.js",
    "static/chunks/f7813_next_dist_compiled_react-dom_8262c337._.js",
    "static/chunks/f7813_next_dist_compiled_next-devtools_index_a13d571c.js",
    "static/chunks/f7813_next_dist_compiled_2235c785._.js",
    "static/chunks/f7813_next_dist_client_7d63aa88._.js",
    "static/chunks/f7813_next_dist_55b9482d._.js",
    "static/chunks/69652_@swc_helpers_cjs_77b72907._.js",
    "static/chunks/_a0ff3932._.js",
    "static/chunks/turbopack-_2e1838c7._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];